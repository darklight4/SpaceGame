﻿'Programmed by Timothy Rediehs on 9/?/14/
'Description: Just a little game I made.
'   Objective is to not run out of fuel
'   figure the rest out :D
'If you use this code, give me credit
Public Class Form1
    Public decGrav As Double = -0.3
    Public intJump As Double = 5
    Public intCurrent As Integer = 100
    Public intTime As Integer = 0
    Public intFuel As Integer = 1800
    Public intFuelConsumption As Integer = 2
    Dim intCount As Integer
    Public intScore As Integer
    Dim blnFuelTrue As Boolean
    Dim picFuel As New PictureBox
    Dim lblFuelAmmount As New Label
    Dim intFuelCount As Integer
    Dim picSpeedOrb As New PictureBox
    Dim lblSpeedLife As New Label
    Dim intSpeedCount As Integer
    Dim blnSpeedTrue As Boolean
    Public intSpeed As Integer = 12
    Dim blnSpeedBoost As Boolean
    Dim intSpeedRoll As Integer
    Dim pgbSpeed As New ProgressBar
    Dim lblSpeed As New Label
    Dim picJumpOrb As New PictureBox
    Dim lblJumplife As New Label
    Dim blnJumpTrue As Boolean
    Dim intJumpCount As Integer
    Dim blnJumpBoost As Boolean
    Dim pgbJump As New ProgressBar
    Dim lblJump As New Label
    Dim intJumpRoll As Integer
    Dim intFuelSaverRoll As Integer
    Dim picFuelSaverOrb As New PictureBox
    Dim lblFuelSaverLife As New Label
    Dim blnFuelSaverTrue As Boolean
    Dim intFuelSaverCount As Integer
    Dim blnFuelSaverBoost As Boolean
    Dim pgbFuelSaver As New ProgressBar
    Dim lblFuelSaver As New Label
    Dim rndSpawn As New Random
    Dim picTeleportOrb As New PictureBox
    Dim lblTeleportLife As New Label
    Dim intTeleportCount As Integer
    Dim blnTeleportTrue As Boolean
    Dim intTeleportRoll As Integer
    Dim intTeleports As Integer


    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            intTime = -2
        End If
        If e.KeyCode = Keys.X Then
            Me.Close()
        End If
        If e.KeyCode = Keys.P Then
            tmrMain.Enabled = False
        End If
        If e.KeyCode = Keys.S Then
            tmrMain.Enabled = True
        End If
    End Sub

    Private Sub shipHop()
        If picPlayer.Top > Me.Height + 100 Then
            intCurrent = 100
            intTime = -10
            intFuel -= 200
        End If

        'picPlayer.Top = 600 - (decGrav * intTime ^ 2 + intJump * intTime + intCurrent)
        picPlayer.Top -= decGrav * intTime ^ 2 + intJump * intTime
        If picPlayer.Top < 100 Then
            picPlayer.Top = 100
        End If
        'intCurrent = 600 - picPlayer.Top
        If intTime <= 20 Then
            intTime += 1
        End If

    End Sub

    Private Sub intTimer1_Tick(sender As Object, e As EventArgs) Handles tmrMain.Tick

        intCount += 1
        shipHop()
        checkMouse()
        changeFuel()
        If intCount - intFuelCount = 150 Then
            generateFuel()
        End If

        If blnFuelTrue = True Then
            FuelTimer(intCount, intFuelCount)
        End If
        If intCount - intSpeedRoll = 50 And blnSpeedTrue = False And blnSpeedBoost = False Then
            generateSpeed()
        End If

        If blnSpeedTrue = True Then
            SpeedTimer(intCount, intSpeedCount)
        End If

        If blnSpeedBoost = True Then
            SpeedBoost(intCount, intSpeedCount)
        End If
        If intCount - intJumpRoll = 50 And blnJumpTrue = False And blnJumpBoost = False Then
            generateJump()
        End If

        If blnJumpTrue = True Then
            JumpTimer(intCount, intJumpCount)
        End If

        If blnJumpBoost = True Then
            JumpBoost(intCount, intJumpCount)
        End If
        intScore += intTime / 5 + 1
        lblScore.Text = "Score: " & intScore
        If intCount - intFuelSaverRoll = 150 And blnFuelSaverTrue = False And blnFuelSaverBoost = False Then
            generateFuelSaver()
        End If
        If blnFuelSaverTrue = True Then
            FuelSaverTimer(intCount, intFuelSaverCount)
        End If
        If blnFuelSaverBoost = True Then
            FuelSaverBoost(intCount, intFuelSaverCount)
        End If
        If intCount - intTeleportRoll = 50 And blnTeleportTrue = False Then
            generateTeleport()
        End If

        If blnTeleportTrue = True Then
            TeleportTimer(intCount, intTeleportCount)
        End If
        lblTp.Text = "Teleports: " & intTeleports

    End Sub

    Private Sub checkMouse()
        If MousePosition.X > picPlayer.Left And picPlayer.Left <= 1840 Then
            picPlayer.Left += intSpeed
        End If
        If MousePosition.X < picPlayer.Left Then
            picPlayer.Left -= intSpeed
        End If
    End Sub
    Private Sub changeFuel()
        intFuel -= intFuelConsumption
        If intFuel > 0 Then
            pgbFuel.Value = intFuel
        End If
        If intFuel <= 0 Then
            tmrMain.Enabled = False
            MessageBox.Show("You got a score of " & intScore, "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Dim result As Integer = MessageBox.Show("Play Again?", "Game Over", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If result = DialogResult.Yes Then
                intFuel = 1800
                intScore = 0
                picPlayer.Location = New Point(300, 300)
                tmrMain.Enabled = True
            ElseIf result = DialogResult.No Then
                Me.Close()
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("X to Exit")
        Me.Location = New Point(0, 0)
        Me.Size = SystemInformation.PrimaryMonitorSize
        tmrMain.Enabled = True
    End Sub

    Private Sub generateFuel()
        'random fuel spot
        Dim intLocX As Integer = rndSpawn.Next(0, 1820)
        Dim intLocY As Integer = rndSpawn.Next(100, 980)
        'picture props
        picFuel.Image = My.Resources._5614_256x256x32
        picFuel.Location = New Point(intLocX, intLocY)
        picFuel.Size = New Size(60, 60)
        picFuel.SizeMode = PictureBoxSizeMode.StretchImage
        'countdown label props
        lblFuelAmmount.Location = New Point(intLocX, intLocY + 60)
        lblFuelAmmount.AutoSize = True
        lblFuelAmmount.Font = New Font(lblFuelAmmount.Font.FontFamily, 12)
        'add picturebox
        Me.Controls.Add(picFuel)
        Me.Controls.Add(lblFuelAmmount)
        'marks now as last time fuel was generated; this is used in FuelTimer to keep track of how long it was on screen
        intFuelCount = intCount
        'tells timer that a fuel orb is on the screen
        blnFuelTrue = True
    End Sub
    Private Sub FuelTimer(intNow As Integer, intSpawned As Integer)
        'defines the count
        Dim intTimeInPlay As Integer = intNow - intSpawned
        'makes the label count down
        lblFuelAmmount.Text = 150 - intTimeInPlay
        'checks for boundary intersetion
        If picPlayer.Bounds.IntersectsWith(picFuel.Bounds) Then
            'increases fuel
            intFuel += 250 - intTimeInPlay
            'stops fuel from going over max
            If intFuel > 1800 Then
                intFuel = 1800
            End If
            'removes picture and lavel
            Me.Controls.Remove(picFuel)
            Me.Controls.Remove(lblFuelAmmount)
            'increases score
            intScore += 200 - intTimeInPlay
            'tells timer there is no longer a fuel orb on screen
            blnFuelTrue = False
        End If
        'cheack whether fuel was onscreen for more than 150 ticks
        If intTimeInPlay = 150 Then
            'removes fuel and tells timer it is gone if true
            Me.Controls.Remove(picFuel)
            Me.Controls.Remove(lblFuelAmmount)
            blnFuelTrue = False
        End If
    End Sub
    Private Sub generateSpeed()
        Dim intSpeedSpawnChance As Integer
        intSpeedSpawnChance = rndSpawn.Next(1, 101)
        intSpeedRoll = intCount
        If intSpeedSpawnChance >= 91 Then
            Dim intLocX As Integer = rndSpawn.Next(0, 1820)
            Dim intLocY As Integer = rndSpawn.Next(100, 980)
            picSpeedOrb.Image = My.Resources.blue_orb
            picSpeedOrb.Location = New Point(intLocX, intLocY)
            picSpeedOrb.Size = New Size(60, 60)
            picSpeedOrb.SizeMode = PictureBoxSizeMode.StretchImage
            lblSpeedLife.Location = New Point(intLocX, intLocY + 60)
            lblSpeedLife.AutoSize = True
            lblSpeedLife.Font = New Font(lblFuelAmmount.Font.FontFamily, 12)
            Me.Controls.Add(picSpeedOrb)
            Me.Controls.Add(lblSpeedLife)
            blnSpeedTrue = True
            intSpeedCount = intCount
        End If

    End Sub

    Private Sub SpeedTimer(intNow As Integer, intSpawned As Integer)
        Dim intTimeInPlay As Integer = intNow - intSpawned
        lblSpeedLife.Text = 150 - intTimeInPlay
        If picPlayer.Bounds.IntersectsWith(picSpeedOrb.Bounds) Then
            blnSpeedBoost = True
            blnSpeedTrue = False
            intSpeed = 25
            Me.Controls.Remove(picSpeedOrb)
            Me.Controls.Remove(lblSpeedLife)
            pgbSpeed.Location = New Point(100, 1030)
            pgbSpeed.Size = New Size(200, 20)
            pgbSpeed.Maximum = 250
            pgbSpeed.Value = 250
            pgbSpeed.Visible = True
            lblSpeed.Text = "Speed:"
            lblSpeed.Location = New Point(0, 1020)
            lblSpeed.Font = New Font(lblSpeed.Font.FontFamily, 18)
            lblSpeed.AutoSize = True
            Me.Controls.Add(pgbSpeed)
            Me.Controls.Add(lblSpeed)
            intSpeedCount = intCount
            intScore += 400 - intTimeInPlay * 3
        End If
        If intTimeInPlay = 150 Then
            Me.Controls.Remove(picSpeedOrb)
            Me.Controls.Remove(lblSpeedLife)
            blnSpeedTrue = False
            intSpeedRoll = intCount
            intSpeedCount = intCount
        End If
    End Sub
    Private Sub SpeedBoost(intNow As Integer, intSpawned As Integer)
        Dim intSpeedTimeBoosted As Integer = intNow - intSpawned
        If intSpeedTimeBoosted = 250 Then
            intSpeed = 12
            Me.Controls.Remove(pgbSpeed)
            Me.Controls.Remove(lblSpeed)
            blnSpeedBoost = False
            intSpeedCount = intCount
            intSpeedRoll = intCount
        End If
        pgbSpeed.Value = 250 - intSpeedTimeBoosted
    End Sub
    Private Sub generateJump()
        Dim intJumpSpawnChance As Integer
        intJumpSpawnChance = rndSpawn.Next(1, 101)
        intJumpRoll = intCount
        If intJumpSpawnChance >= 91 Then
            Dim intLocX As Integer = rndSpawn.Next(0, 1820)
            Dim intLocY As Integer = rndSpawn.Next(100, 980)
            picJumpOrb.Image = My.Resources.red_orb_by_akiranyo_d228g2k
            picJumpOrb.Location = New Point(intLocX, intLocY)
            picJumpOrb.Size = New Size(60, 60)
            picJumpOrb.SizeMode = PictureBoxSizeMode.StretchImage
            lblJumplife.Location = New Point(intLocX, intLocY + 60)
            lblJumplife.AutoSize = True
            lblJumplife.Font = New Font(lblFuelAmmount.Font.FontFamily, 12)
            Me.Controls.Add(picJumpOrb)
            Me.Controls.Add(lblJumplife)
            blnJumpTrue = True
            intJumpCount = intCount
        End If

    End Sub

    Private Sub JumpTimer(intNow As Integer, intSpawned As Integer)
        Dim intTimeInPlay As Integer = intNow - intSpawned
        lblJumplife.Text = 150 - intTimeInPlay
        If picPlayer.Bounds.IntersectsWith(picJumpOrb.Bounds) Then
            blnJumpBoost = True
            blnJumpTrue = False
            intJump = 9
            decGrav = -0.5
            Me.Controls.Remove(picJumpOrb)
            Me.Controls.Remove(lblJumplife)
            pgbJump.Location = New Point(500, 1030)
            pgbJump.Size = New Size(200, 20)
            pgbJump.Maximum = 250
            pgbJump.Value = 250
            pgbJump.Visible = True
            lblJump.Text = "Jump:"
            lblJump.Location = New Point(400, 1020)
            lblJump.Font = New Font(lblJump.Font.FontFamily, 18)
            lblJump.AutoSize = True
            Me.Controls.Add(pgbJump)
            Me.Controls.Add(lblJump)
            intJumpCount = intCount
            intScore += 300 - intTimeInPlay * 2
        End If
        If intTimeInPlay >= 149 Then
            Me.Controls.Remove(picJumpOrb)
            Me.Controls.Remove(lblJumplife)
            blnJumpTrue = False
            intJumpRoll = intCount
            intJumpCount = intCount
        End If
    End Sub
    Private Sub JumpBoost(intNow As Integer, intSpawned As Integer)
        Dim intTimeInPlay As Integer = intNow - intSpawned

        If intTimeInPlay > 250 Then
            intJump = 5
            decGrav = -0.3
            Me.Controls.Remove(pgbJump)
            Me.Controls.Remove(lblJump)
            blnJumpBoost = False
            intJumpCount = intCount
            intJumpRoll = intCount
        End If
        Try
            pgbJump.Value = 250 - intTimeInPlay
        Catch
            pgbJump.Value = 0
        End Try
    End Sub
    Private Sub generateFuelSaver()
        Dim intFuelSaverSpawnChance As Integer
        intFuelSaverSpawnChance = rndSpawn.Next(1, 101)
        intFuelSaverRoll = intCount
        If intFuelSaverSpawnChance >= 95 Then
            Dim intLocX As Integer = rndSpawn.Next(0, 1820)
            Dim intLocY As Integer = rndSpawn.Next(100, 980)
            picFuelSaverOrb.Image = My.Resources.Gold_Orb_by_niccey
            picFuelSaverOrb.Location = New Point(intLocX, intLocY)
            picFuelSaverOrb.Size = New Size(60, 60)
            picFuelSaverOrb.SizeMode = PictureBoxSizeMode.StretchImage
            lblFuelSaverLife.Location = New Point(intLocX, intLocY + 60)
            lblFuelSaverLife.AutoSize = True
            lblFuelSaverLife.Font = New Font(lblFuelAmmount.Font.FontFamily, 12)
            Me.Controls.Add(picFuelSaverOrb)
            Me.Controls.Add(lblFuelSaverLife)
            blnFuelSaverTrue = True
            intFuelSaverCount = intCount
        End If
    End Sub
    Private Sub FuelSaverTimer(intNow As Integer, intSpawned As Integer)
        Dim intTimeInPlay As Integer = intNow - intSpawned
        lblFuelSaverLife.Text = 150 - intTimeInPlay
        If picPlayer.Bounds.IntersectsWith(picFuelSaverOrb.Bounds) Then
            blnFuelSaverBoost = True
            blnFuelSaverTrue = False
            intFuelConsumption = 1
            Me.Controls.Remove(picFuelSaverOrb)
            Me.Controls.Remove(lblFuelSaverLife)
            pgbFuelSaver.Location = New Point(900, 1030)
            pgbFuelSaver.Size = New Size(200, 20)
            pgbFuelSaver.Maximum = 250
            pgbFuelSaver.Value = 250
            pgbFuelSaver.Visible = True
            lblFuelSaver.Text = "Fuel Saver:"
            lblFuelSaver.Location = New Point(750, 1020)
            lblFuelSaver.Font = New Font(lblSpeed.Font.FontFamily, 18)
            lblFuelSaver.AutoSize = True
            Me.Controls.Add(pgbFuelSaver)
            Me.Controls.Add(lblFuelSaver)
            intFuelSaverCount = intCount
            intScore += 800 - intTimeInPlay * 6
        End If
        If intTimeInPlay = 150 Then
            Me.Controls.Remove(picFuelSaverOrb)
            Me.Controls.Remove(lblFuelSaverLife)
            blnFuelSaverTrue = False
            intFuelSaverRoll = intCount
            intFuelSaverCount = intCount
        End If
    End Sub
    Private Sub FuelSaverBoost(intNow As Integer, intSpawned As Integer)
        Dim intFuelSaverTimeBoosted As Integer = intNow - intSpawned
        If intFuelSaverTimeBoosted = 250 Then
            intFuelConsumption = 2
            Me.Controls.Remove(pgbFuelSaver)
            Me.Controls.Remove(lblFuelSaver)
            blnFuelSaverBoost = False
            intFuelSaverCount = intCount
            intFuelSaverRoll = intCount
        End If
        pgbFuelSaver.Value = 250 - intFuelSaverTimeBoosted
    End Sub
    Private Sub generateTeleport()
        Dim intTeleportSpawnChance As Integer
        intTeleportSpawnChance = rndSpawn.Next(1, 101)
        intTeleportRoll = intCount
        If intTeleportSpawnChance >= 91 Then
            Dim intLocX As Integer = rndSpawn.Next(0, 1820)
            Dim intLocY As Integer = rndSpawn.Next(100, 980)
            picTeleportOrb.Image = My.Resources.Purple_WhiteOrb
            picTeleportOrb.Location = New Point(intLocX, intLocY)
            picTeleportOrb.Size = New Size(50, 50)
            picTeleportOrb.SizeMode = PictureBoxSizeMode.StretchImage
            lblTeleportLife.Location = New Point(intLocX, intLocY + 60)
            lblTeleportLife.AutoSize = True
            lblTeleportLife.Font = New Font(lblFuelAmmount.Font.FontFamily, 12)
            Me.Controls.Add(picTeleportOrb)
            Me.Controls.Add(lblTeleportLife)
            blnTeleportTrue = True
            intTeleportCount = intCount
        End If
    End Sub
    Private Sub TeleportTimer(intNow As Integer, intSpawned As Integer)
        Dim intTimeInPlay As Integer = intNow - intSpawned
        lblTeleportLife.Text = 150 - intTimeInPlay
        If picPlayer.Bounds.IntersectsWith(picTeleportOrb.Bounds) Then
            blnTeleportTrue = False
            intTeleports += 1
            Me.Controls.Remove(picTeleportOrb)
            Me.Controls.Remove(lblTeleportLife)
            intTeleportCount = intCount
            intScore += 400 - intTimeInPlay * 3
            intTeleportCount = intCount
            intTeleportRoll = intCount
        End If
        If intTimeInPlay = 150 Then
            Me.Controls.Remove(picTeleportOrb)
            Me.Controls.Remove(lblTeleportLife)
            blnTeleportTrue = False
            intTeleportRoll = intCount
            intTeleportCount = intCount
        End If
    End Sub

    Private Sub Form1_MouseClick(sender As Object, e As MouseEventArgs) Handles MyClass.MouseClick
        If intTeleports > 0 Then
            picPlayer.Top = MousePosition.Y - 50
            picPlayer.Left = MousePosition.X - 50
            intTeleports -= 1
        End If
    End Sub
    'bomb about to go off unless you get to a safe zone
    'diff levels
End Class
