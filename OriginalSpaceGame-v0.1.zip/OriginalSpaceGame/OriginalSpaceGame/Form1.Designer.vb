﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrMain = New System.Windows.Forms.Timer(Me.components)
        Me.lblScore = New System.Windows.Forms.Label()
        Me.pgbFuel = New System.Windows.Forms.ProgressBar()
        Me.lblFuel = New System.Windows.Forms.Label()
        Me.lblTp = New System.Windows.Forms.Label()
        Me.lblBound = New System.Windows.Forms.Label()
        Me.picPlayer = New System.Windows.Forms.PictureBox()
        Me.lblWarning = New System.Windows.Forms.Label()
        CType(Me.picPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrMain
        '
        Me.tmrMain.Interval = 25
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScore.ForeColor = System.Drawing.Color.Green
        Me.lblScore.Location = New System.Drawing.Point(101, 49)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(102, 29)
        Me.lblScore.TabIndex = 1
        Me.lblScore.Text = "Score: 0"
        '
        'pgbFuel
        '
        Me.pgbFuel.Location = New System.Drawing.Point(106, 12)
        Me.pgbFuel.Maximum = 1800
        Me.pgbFuel.Name = "pgbFuel"
        Me.pgbFuel.Size = New System.Drawing.Size(1802, 34)
        Me.pgbFuel.TabIndex = 2
        Me.pgbFuel.Value = 1800
        '
        'lblFuel
        '
        Me.lblFuel.AutoSize = True
        Me.lblFuel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFuel.ForeColor = System.Drawing.Color.Green
        Me.lblFuel.Location = New System.Drawing.Point(12, 12)
        Me.lblFuel.Name = "lblFuel"
        Me.lblFuel.Size = New System.Drawing.Size(88, 37)
        Me.lblFuel.TabIndex = 3
        Me.lblFuel.Text = "Fuel:"
        '
        'lblTp
        '
        Me.lblTp.AutoSize = True
        Me.lblTp.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTp.ForeColor = System.Drawing.Color.Green
        Me.lblTp.Location = New System.Drawing.Point(384, 49)
        Me.lblTp.Name = "lblTp"
        Me.lblTp.Size = New System.Drawing.Size(142, 29)
        Me.lblTp.TabIndex = 4
        Me.lblTp.Text = "Teleports: 0"
        '
        'lblBound
        '
        Me.lblBound.BackColor = System.Drawing.Color.Green
        Me.lblBound.ForeColor = System.Drawing.Color.Green
        Me.lblBound.Location = New System.Drawing.Point(0, 95)
        Me.lblBound.Name = "lblBound"
        Me.lblBound.Size = New System.Drawing.Size(1920, 5)
        Me.lblBound.TabIndex = 5
        '
        'picPlayer
        '
        Me.picPlayer.BackColor = System.Drawing.Color.MidnightBlue
        Me.picPlayer.Image = Global.OriginalSpaceGame.My.Resources.Resources.flying_saucer3
        Me.picPlayer.Location = New System.Drawing.Point(446, 449)
        Me.picPlayer.Name = "picPlayer"
        Me.picPlayer.Size = New System.Drawing.Size(80, 72)
        Me.picPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayer.TabIndex = 0
        Me.picPlayer.TabStop = False
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWarning.ForeColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblWarning.Location = New System.Drawing.Point(1767, 49)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(141, 29)
        Me.lblWarning.TabIndex = 6
        Me.lblWarning.Text = "WARNING!"
        Me.lblWarning.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(1920, 1080)
        Me.Controls.Add(Me.lblWarning)
        Me.Controls.Add(Me.lblBound)
        Me.Controls.Add(Me.lblTp)
        Me.Controls.Add(Me.lblFuel)
        Me.Controls.Add(Me.pgbFuel)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.picPlayer)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmrMain As System.Windows.Forms.Timer
    Friend WithEvents picPlayer As System.Windows.Forms.PictureBox
    Friend WithEvents lblScore As System.Windows.Forms.Label
    Friend WithEvents pgbFuel As System.Windows.Forms.ProgressBar
    Friend WithEvents lblFuel As System.Windows.Forms.Label
    Friend WithEvents lblTp As System.Windows.Forms.Label
    Friend WithEvents lblBound As System.Windows.Forms.Label
    Friend WithEvents lblWarning As System.Windows.Forms.Label

End Class
