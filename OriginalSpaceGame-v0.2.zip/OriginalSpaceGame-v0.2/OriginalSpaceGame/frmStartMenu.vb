﻿Public Class frmStartMenu
    Dim cheats As String = "X"
    Dim i As Integer
    Dim intTime As Integer
    Dim blnHop As Boolean
    Private Sub lblPlay_Click(sender As Object, e As EventArgs) Handles lblPlay.Click
        Form1.cheats = Me.cheats
        Form1.Show()

        Me.Close()
    End Sub

    Private Sub lblInstructions_Click(sender As Object, e As EventArgs) Handles lblInstructions.Click
        picPlayOrb.Visible = False
        picInstructionsOrb.Visible = False
        picCheatOrb.Visible = False
        lblPlay.Visible = False
        lblInstructions.Visible = False
        lblCheat.Visible = False
        lblBasics.Visible = True
        lblPickUps.Visible = True
        lblControls.Visible = True
        lblBack.Visible = True
        picBack.Visible = True
        lblTitle.Text = "Instructions"
        lblHowToPlay.Visible = True
        lblHowToPlay.Size = New Size(775, 600)
        lblHowToPlay.Text = "How to play:" & Environment.NewLine & Environment.NewLine & "1. PRESS space to hop up on the screen" & Environment.NewLine &
        "2. The ship will follow your mouse for horizontal movement" & Environment.NewLine &
        "3. Go as long as you can without running out of fuel" & Environment.NewLine &
        "4. Watch out for bombs, you will loose fuel."
        lblBasics.Font = New Font("Century", 24.0, FontStyle.Underline)
    End Sub


    Private Sub lblBack_Click(sender As Object, e As EventArgs) Handles lblBack.Click
        lblHowToPlay.Text = ""
        lblHowToPlay.Size = New Size(1, 1)
        lblTitle.Text = "Space Game"
        picPlayOrb.Visible = True
        picInstructionsOrb.Visible = True
        picCheatOrb.Visible = True
        lblPlay.Visible = True
        lblInstructions.Visible = True
        lblCheat.Visible = True
        lblBasics.Visible = False
        lblPickUps.Visible = False
        lblControls.Visible = False
        txtCheats.Visible = False
        lblCheatSub.Visible = False
        lblBack.Visible = False
        picBack.Visible = False
        lblHowToPlay.Visible = False
    End Sub

    Private Sub lblExit_Click(sender As Object, e As EventArgs) Handles lblExit.Click
        Me.Close()
    End Sub

    Private Sub lblBasics_Click(sender As Object, e As EventArgs) Handles lblBasics.Click
        lblHowToPlay.Text = "How to play:" & Environment.NewLine & Environment.NewLine & "1. PRESS space to hop up on the screen" & Environment.NewLine &
        "2. The ship will follow your mouse for horizontal movement" & Environment.NewLine &
        "3. Go as long as you can without running out of fuel" & Environment.NewLine &
        "4. Watch out for bombs, you will loose fuel."
        lblBasics.Font = New Font("Century", 24.0, FontStyle.Underline)
        lblPickUps.Font = New Font("Century", 24.0)
        lblControls.Font = New Font("Century", 24.0)
    End Sub

    Private Sub lblPickUps_Click(sender As Object, e As EventArgs) Handles lblPickUps.Click
        lblHowToPlay.Text = "Pick -Ups:" & Environment.NewLine & Environment.NewLine &
        "Green : More Fuel" & Environment.NewLine &
        "Red: verticle motion boost (Jump boost)" & Environment.NewLine &
        "Blue: Horizontal motion boost (Speed boost)" & Environment.NewLine &
        "Purple: Gain a Teleport" & Environment.NewLine &
        "Yellow: Fuel conservation" & Environment.NewLine & Environment.NewLine &
        "Avoid:" & Environment.NewLine & Environment.NewLine &
        "Black: Bomb"
        lblBasics.Font = New Font("Century", 24.0)
        lblPickUps.Font = New Font("Century", 24.0, FontStyle.Underline)
        lblControls.Font = New Font("Century", 24.0)
    End Sub

    Private Sub lblControls_Click(sender As Object, e As EventArgs) Handles lblControls.Click
        lblHowToPlay.Text = "Controls:" & Environment.NewLine & Environment.NewLine &
        "Mouse:  Horizontal movement" & Environment.NewLine &
        "Space:  Verticle Hop" & Environment.NewLine &
        "Mouse Click : Use Teleport" & Environment.NewLine &
        "'X': Exit" & Environment.NewLine &
        "'P': Pause" & Environment.NewLine &
        "'S': Unpause"
        lblBasics.Font = New Font("Century", 24.0)
        lblPickUps.Font = New Font("Century", 24.0)
        lblControls.Font = New Font("Century", 24.0, FontStyle.Underline)
    End Sub
    Private Sub Hover(lblHover As Label, clrColor As Color)
        lblHover.ForeColor = clrColor

    End Sub

    Private Sub lblPlay_MouseEnter(sender As Object, e As EventArgs) Handles lblPlay.MouseEnter, lblInstructions.MouseEnter, lblCheat.MouseEnter, lblBack.MouseEnter, lblBasics.MouseEnter,
        lblPickUps.MouseEnter, lblControls.MouseEnter, lblExit.MouseEnter, lblCheatSub.MouseEnter

        Dim lblHoveredLabel As Label
        lblHoveredLabel = CType(sender, Label)
        Hover(lblHoveredLabel, Color.Yellow)
    End Sub

    Private Sub lblPlay_MouseLeave(sender As Object, e As EventArgs) Handles lblPlay.MouseLeave, lblInstructions.MouseLeave, lblCheat.MouseLeave, lblBack.MouseLeave, lblBasics.MouseLeave,
        lblPickUps.MouseLeave, lblControls.MouseLeave, lblExit.MouseLeave, lblCheatSub.MouseLeave
        Dim lblHoveredLabel As Label
        lblHoveredLabel = CType(sender, Label)
        Hover(lblHoveredLabel, Color.Green)
    End Sub

    Private Sub lblCheat_Click(sender As Object, e As EventArgs) Handles lblCheat.Click
        picPlayOrb.Visible = False
        picInstructionsOrb.Visible = False
        picCheatOrb.Visible = False
        lblPlay.Visible = False
        lblInstructions.Visible = False
        lblCheat.Visible = False
        txtCheats.Visible = True
        lblCheatSub.Visible = True
        lblTitle.Text = "Cheat Codes"
        lblBack.Visible = True
        picBack.Visible = True
    End Sub

    Private Sub lblCheatSub_Click(sender As Object, e As EventArgs) Handles lblCheatSub.Click
        If i < 5 Then
            cheats = cheats & "X" & txtCheats.Text
            i += 1
            txtCheats.Text = ""
        Else
            lblCheatSub.Text = "No More"
            lblCheatSub.ForeColor = Color.Orange
        End If
    End Sub

    Private Sub tmrStart_Tick(sender As Object, e As EventArgs) Handles tmrStart.Tick
        picPlayerAnim.Top -= -0.4 * intTime ^ 2 + 6.5 * intTime
        If intTime < 20 Then
            intTime += 1
        End If
        If picPlayerAnim.Top > 500 And intTime > 10 Then
            blnHop = True
        End If
        If blnHop = True Then
            intTime = -1
            blnHop = False
        End If
    End Sub
End Class