﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStartMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.picPlayerAnim = New System.Windows.Forms.PictureBox()
        Me.pibBomb = New System.Windows.Forms.PictureBox()
        Me.picGreen = New System.Windows.Forms.PictureBox()
        Me.lblPlay = New System.Windows.Forms.Label()
        Me.picPlayOrb = New System.Windows.Forms.PictureBox()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.picInstructionsOrb = New System.Windows.Forms.PictureBox()
        Me.lblCheat = New System.Windows.Forms.Label()
        Me.picCheatOrb = New System.Windows.Forms.PictureBox()
        Me.lblHowToPlay = New System.Windows.Forms.Label()
        Me.picBack = New System.Windows.Forms.PictureBox()
        Me.lblBack = New System.Windows.Forms.Label()
        Me.picExit = New System.Windows.Forms.PictureBox()
        Me.lblExit = New System.Windows.Forms.Label()
        Me.lblBasics = New System.Windows.Forms.Label()
        Me.lblPickUps = New System.Windows.Forms.Label()
        Me.lblControls = New System.Windows.Forms.Label()
        Me.txtCheats = New System.Windows.Forms.TextBox()
        Me.lblCheatSub = New System.Windows.Forms.Label()
        Me.tmrStart = New System.Windows.Forms.Timer(Me.components)
        Me.lblScore = New System.Windows.Forms.Label()
        Me.lblHighScore = New System.Windows.Forms.Label()
        CType(Me.picPlayerAnim, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pibBomb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlayOrb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picInstructionsOrb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCheatOrb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Century", 80.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Green
        Me.lblTitle.Location = New System.Drawing.Point(351, 21)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(666, 129)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Space Game"
        '
        'picPlayerAnim
        '
        Me.picPlayerAnim.BackColor = System.Drawing.Color.MidnightBlue
        Me.picPlayerAnim.Image = Global.OriginalSpaceGame.My.Resources.Resources.flying_saucer3
        Me.picPlayerAnim.Location = New System.Drawing.Point(80, 424)
        Me.picPlayerAnim.Name = "picPlayerAnim"
        Me.picPlayerAnim.Size = New System.Drawing.Size(80, 72)
        Me.picPlayerAnim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayerAnim.TabIndex = 1
        Me.picPlayerAnim.TabStop = False
        '
        'pibBomb
        '
        Me.pibBomb.BackColor = System.Drawing.Color.MidnightBlue
        Me.pibBomb.Image = Global.OriginalSpaceGame.My.Resources.Resources.BombOrb
        Me.pibBomb.Location = New System.Drawing.Point(202, 47)
        Me.pibBomb.Name = "pibBomb"
        Me.pibBomb.Size = New System.Drawing.Size(72, 77)
        Me.pibBomb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pibBomb.TabIndex = 2
        Me.pibBomb.TabStop = False
        '
        'picGreen
        '
        Me.picGreen.BackColor = System.Drawing.Color.MidnightBlue
        Me.picGreen.Image = Global.OriginalSpaceGame.My.Resources.Resources._5614_256x256x32
        Me.picGreen.Location = New System.Drawing.Point(39, 47)
        Me.picGreen.Name = "picGreen"
        Me.picGreen.Size = New System.Drawing.Size(80, 77)
        Me.picGreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGreen.TabIndex = 3
        Me.picGreen.TabStop = False
        '
        'lblPlay
        '
        Me.lblPlay.AutoSize = True
        Me.lblPlay.Font = New System.Drawing.Font("Century", 36.0!)
        Me.lblPlay.ForeColor = System.Drawing.Color.Green
        Me.lblPlay.Location = New System.Drawing.Point(563, 268)
        Me.lblPlay.Name = "lblPlay"
        Me.lblPlay.Size = New System.Drawing.Size(125, 57)
        Me.lblPlay.TabIndex = 4
        Me.lblPlay.Text = "Play"
        '
        'picPlayOrb
        '
        Me.picPlayOrb.BackColor = System.Drawing.Color.MidnightBlue
        Me.picPlayOrb.Image = Global.OriginalSpaceGame.My.Resources.Resources._5614_256x256x32
        Me.picPlayOrb.Location = New System.Drawing.Point(477, 259)
        Me.picPlayOrb.Name = "picPlayOrb"
        Me.picPlayOrb.Size = New System.Drawing.Size(80, 77)
        Me.picPlayOrb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayOrb.TabIndex = 5
        Me.picPlayOrb.TabStop = False
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Century", 36.0!)
        Me.lblInstructions.ForeColor = System.Drawing.Color.Green
        Me.lblInstructions.Location = New System.Drawing.Point(563, 382)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(295, 57)
        Me.lblInstructions.TabIndex = 6
        Me.lblInstructions.Text = "Instructions"
        '
        'picInstructionsOrb
        '
        Me.picInstructionsOrb.BackColor = System.Drawing.Color.MidnightBlue
        Me.picInstructionsOrb.Image = Global.OriginalSpaceGame.My.Resources.Resources.blue_orb
        Me.picInstructionsOrb.Location = New System.Drawing.Point(479, 372)
        Me.picInstructionsOrb.Name = "picInstructionsOrb"
        Me.picInstructionsOrb.Size = New System.Drawing.Size(76, 76)
        Me.picInstructionsOrb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picInstructionsOrb.TabIndex = 7
        Me.picInstructionsOrb.TabStop = False
        '
        'lblCheat
        '
        Me.lblCheat.AutoSize = True
        Me.lblCheat.Font = New System.Drawing.Font("Century", 36.0!)
        Me.lblCheat.ForeColor = System.Drawing.Color.Green
        Me.lblCheat.Location = New System.Drawing.Point(563, 496)
        Me.lblCheat.Name = "lblCheat"
        Me.lblCheat.Size = New System.Drawing.Size(352, 57)
        Me.lblCheat.TabIndex = 8
        Me.lblCheat.Text = "Wanna Cheat?"
        '
        'picCheatOrb
        '
        Me.picCheatOrb.BackColor = System.Drawing.Color.MidnightBlue
        Me.picCheatOrb.Image = Global.OriginalSpaceGame.My.Resources.Resources.Gold_Orb_by_niccey
        Me.picCheatOrb.Location = New System.Drawing.Point(475, 484)
        Me.picCheatOrb.Name = "picCheatOrb"
        Me.picCheatOrb.Size = New System.Drawing.Size(84, 82)
        Me.picCheatOrb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCheatOrb.TabIndex = 9
        Me.picCheatOrb.TabStop = False
        '
        'lblHowToPlay
        '
        Me.lblHowToPlay.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHowToPlay.ForeColor = System.Drawing.Color.Green
        Me.lblHowToPlay.Location = New System.Drawing.Point(231, 169)
        Me.lblHowToPlay.Name = "lblHowToPlay"
        Me.lblHowToPlay.Size = New System.Drawing.Size(90, 62)
        Me.lblHowToPlay.TabIndex = 10
        Me.lblHowToPlay.Visible = False
        '
        'picBack
        '
        Me.picBack.BackColor = System.Drawing.Color.MidnightBlue
        Me.picBack.Image = Global.OriginalSpaceGame.My.Resources.Resources.red_orb_by_akiranyo_d228g2k
        Me.picBack.Location = New System.Drawing.Point(12, 696)
        Me.picBack.Name = "picBack"
        Me.picBack.Size = New System.Drawing.Size(55, 52)
        Me.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBack.TabIndex = 11
        Me.picBack.TabStop = False
        Me.picBack.Visible = False
        '
        'lblBack
        '
        Me.lblBack.AutoSize = True
        Me.lblBack.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblBack.ForeColor = System.Drawing.Color.Green
        Me.lblBack.Location = New System.Drawing.Point(73, 704)
        Me.lblBack.Name = "lblBack"
        Me.lblBack.Size = New System.Drawing.Size(91, 38)
        Me.lblBack.TabIndex = 12
        Me.lblBack.Text = "Back"
        Me.lblBack.Visible = False
        '
        'picExit
        '
        Me.picExit.BackColor = System.Drawing.Color.MidnightBlue
        Me.picExit.Image = Global.OriginalSpaceGame.My.Resources.Resources.BombOrb
        Me.picExit.Location = New System.Drawing.Point(1216, 696)
        Me.picExit.Name = "picExit"
        Me.picExit.Size = New System.Drawing.Size(55, 52)
        Me.picExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picExit.TabIndex = 13
        Me.picExit.TabStop = False
        '
        'lblExit
        '
        Me.lblExit.AutoSize = True
        Me.lblExit.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblExit.ForeColor = System.Drawing.Color.Green
        Me.lblExit.Location = New System.Drawing.Point(1277, 704)
        Me.lblExit.Name = "lblExit"
        Me.lblExit.Size = New System.Drawing.Size(79, 38)
        Me.lblExit.TabIndex = 14
        Me.lblExit.Text = "Exit"
        '
        'lblBasics
        '
        Me.lblBasics.AutoSize = True
        Me.lblBasics.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblBasics.ForeColor = System.Drawing.Color.Green
        Me.lblBasics.Location = New System.Drawing.Point(323, 704)
        Me.lblBasics.Name = "lblBasics"
        Me.lblBasics.Size = New System.Drawing.Size(112, 38)
        Me.lblBasics.TabIndex = 15
        Me.lblBasics.Text = "Basics"
        Me.lblBasics.Visible = False
        '
        'lblPickUps
        '
        Me.lblPickUps.AutoSize = True
        Me.lblPickUps.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblPickUps.ForeColor = System.Drawing.Color.Green
        Me.lblPickUps.Location = New System.Drawing.Point(593, 704)
        Me.lblPickUps.Name = "lblPickUps"
        Me.lblPickUps.Size = New System.Drawing.Size(151, 38)
        Me.lblPickUps.TabIndex = 16
        Me.lblPickUps.Text = "Pick-Ups"
        Me.lblPickUps.Visible = False
        '
        'lblControls
        '
        Me.lblControls.AutoSize = True
        Me.lblControls.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblControls.ForeColor = System.Drawing.Color.Green
        Me.lblControls.Location = New System.Drawing.Point(902, 704)
        Me.lblControls.Name = "lblControls"
        Me.lblControls.Size = New System.Drawing.Size(143, 38)
        Me.lblControls.TabIndex = 17
        Me.lblControls.Text = "Controls"
        Me.lblControls.Visible = False
        '
        'txtCheats
        '
        Me.txtCheats.Location = New System.Drawing.Point(498, 184)
        Me.txtCheats.Name = "txtCheats"
        Me.txtCheats.Size = New System.Drawing.Size(358, 20)
        Me.txtCheats.TabIndex = 18
        Me.txtCheats.Visible = False
        '
        'lblCheatSub
        '
        Me.lblCheatSub.AutoSize = True
        Me.lblCheatSub.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblCheatSub.ForeColor = System.Drawing.Color.Green
        Me.lblCheatSub.Location = New System.Drawing.Point(862, 174)
        Me.lblCheatSub.Name = "lblCheatSub"
        Me.lblCheatSub.Size = New System.Drawing.Size(125, 38)
        Me.lblCheatSub.TabIndex = 19
        Me.lblCheatSub.Text = "Submit"
        Me.lblCheatSub.Visible = False
        '
        'tmrStart
        '
        Me.tmrStart.Enabled = True
        Me.tmrStart.Interval = 25
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblScore.ForeColor = System.Drawing.Color.Green
        Me.lblScore.Location = New System.Drawing.Point(999, 96)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(208, 38)
        Me.lblScore.TabIndex = 20
        Me.lblScore.Text = "Last Score: 0"
        '
        'lblHighScore
        '
        Me.lblHighScore.Font = New System.Drawing.Font("Century", 24.0!)
        Me.lblHighScore.ForeColor = System.Drawing.Color.Green
        Me.lblHighScore.Location = New System.Drawing.Point(999, 47)
        Me.lblHighScore.Name = "lblHighScore"
        Me.lblHighScore.Size = New System.Drawing.Size(336, 38)
        Me.lblHighScore.TabIndex = 21
        Me.lblHighScore.Text = "HighScore: 0"
        '
        'frmStartMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(1368, 760)
        Me.Controls.Add(Me.lblHighScore)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.lblCheatSub)
        Me.Controls.Add(Me.txtCheats)
        Me.Controls.Add(Me.lblControls)
        Me.Controls.Add(Me.lblPickUps)
        Me.Controls.Add(Me.lblBasics)
        Me.Controls.Add(Me.lblExit)
        Me.Controls.Add(Me.picExit)
        Me.Controls.Add(Me.lblBack)
        Me.Controls.Add(Me.picBack)
        Me.Controls.Add(Me.lblHowToPlay)
        Me.Controls.Add(Me.picCheatOrb)
        Me.Controls.Add(Me.lblCheat)
        Me.Controls.Add(Me.picInstructionsOrb)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.picPlayOrb)
        Me.Controls.Add(Me.lblPlay)
        Me.Controls.Add(Me.picGreen)
        Me.Controls.Add(Me.pibBomb)
        Me.Controls.Add(Me.picPlayerAnim)
        Me.Controls.Add(Me.lblTitle)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmStartMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmStartMenu"
        CType(Me.picPlayerAnim, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pibBomb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlayOrb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picInstructionsOrb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCheatOrb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents picPlayerAnim As System.Windows.Forms.PictureBox
    Friend WithEvents pibBomb As System.Windows.Forms.PictureBox
    Friend WithEvents picGreen As System.Windows.Forms.PictureBox
    Friend WithEvents lblPlay As System.Windows.Forms.Label
    Friend WithEvents picPlayOrb As System.Windows.Forms.PictureBox
    Friend WithEvents lblInstructions As System.Windows.Forms.Label
    Friend WithEvents picInstructionsOrb As System.Windows.Forms.PictureBox
    Friend WithEvents lblCheat As System.Windows.Forms.Label
    Friend WithEvents picCheatOrb As System.Windows.Forms.PictureBox
    Friend WithEvents lblHowToPlay As System.Windows.Forms.Label
    Friend WithEvents picBack As System.Windows.Forms.PictureBox
    Friend WithEvents lblBack As System.Windows.Forms.Label
    Friend WithEvents picExit As System.Windows.Forms.PictureBox
    Friend WithEvents lblExit As System.Windows.Forms.Label
    Friend WithEvents lblBasics As System.Windows.Forms.Label
    Friend WithEvents lblPickUps As System.Windows.Forms.Label
    Friend WithEvents lblControls As System.Windows.Forms.Label
    Friend WithEvents txtCheats As System.Windows.Forms.TextBox
    Friend WithEvents lblCheatSub As System.Windows.Forms.Label
    Friend WithEvents tmrStart As System.Windows.Forms.Timer
    Friend WithEvents lblScore As System.Windows.Forms.Label
    Friend WithEvents lblHighScore As System.Windows.Forms.Label
End Class
