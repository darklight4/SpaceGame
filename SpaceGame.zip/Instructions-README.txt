How to play: 

1. PRESS space to hop up on the screen 
2. The ship will follow your mouse for horizontal movement 
3. Go as long as you can without running out of fuel

Pick-Ups: 

Green: More Fuel 
Red: verticle motion boost (Jump boost) 
Blue: Horizontal motion boost (Speed boost) 
Purple: Gain a Teleport 
Yellow: Fuel conservation

Controls: 

Mouse: Horizontal movement 
Space: Verticle "Hop" 
Mouse Click: Use Teleport 
"X": Exit 
"P": Pause 
"S": Unpause

Things you shouldn't do:

1."Oh No! I need to go up" *rapidly hits space
	a. Math people out there: the amount the ship moves up = -0.3x^2 + 5x
		where x = the number of ticks (1/40 of a second)
2.Fall about 2 inches below your screen: you will be moved up and loose fuel.